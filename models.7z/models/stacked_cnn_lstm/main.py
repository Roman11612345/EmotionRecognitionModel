import numpy as np
import pandas as pd
import os
import librosa
import librosa.display
import IPython
from IPython.display import Audio
from IPython.display import Image
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from sklearn.preprocessing import StandardScaler

from data_loading import loading
from data_preprocessing import preprocessing
from training import train
from model import HybridModel, TimeDistributed, loss_fnc

data = loading('../../input/ravdess-emotional-speech-audio/audio_speech_actors_01-24/')

n_fft = 1024
win_length = 512
hop_length = 256
SAMPLE_RATE = 48000

EMOTIONS = {1: 'neutral', 2: 'calm', 3: 'happy', 4: 'sad', 5: 'angry', 6: 'fear', 7: 'disgust', 0: 'surprise'}

mel_train_chunked, mel_val_chunked, mel_test_chunked, Y_train, Y_val, Y_test = preprocessing(data, SAMPLE_RATE, n_fft, win_length, hop_length, EMOTIONS)

train(mel_train_chunked, mel_val_chunked, mel_test_chunked, HybridModel, TimeDistributed, loss_fnc, Y_train, Y_val, Y_test, EMOTIONS)